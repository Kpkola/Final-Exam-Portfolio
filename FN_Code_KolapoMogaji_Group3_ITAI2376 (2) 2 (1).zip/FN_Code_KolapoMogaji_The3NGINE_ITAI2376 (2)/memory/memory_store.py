def store_memory(task_description):
    with open('memory_log.txt', 'a') as f:
        f.write(task_description + '\n')
