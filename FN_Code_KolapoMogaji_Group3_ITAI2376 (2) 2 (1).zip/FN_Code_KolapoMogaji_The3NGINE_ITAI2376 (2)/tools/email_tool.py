def send_email(user_input):
    print(f"[Simulated] Sent an email based on input: {user_input}")
