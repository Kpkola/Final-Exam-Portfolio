def schedule_meeting(user_input):
    print(f"[Simulated] Scheduled a meeting based on input: {user_input}")
