from tools.email_tool import send_email
from tools.calendar_tool import schedule_meeting

def classify_task(user_input):
    user_input_lower = user_input.lower()
    if "email" in user_input_lower:
        return "email"
    elif "schedule" in user_input_lower or "meeting" in user_input_lower:
        return "calendar"
    else:
        return "general"

def process_input(user_input):
    task_type = classify_task(user_input)
    if task_type == "email":
        print("→ Detected task: Email generation")
        send_email(user_input)
    elif task_type == "calendar":
        print("→ Detected task: Calendar scheduling")
        schedule_meeting(user_input)
    else:
        print("→ Task not recognized. Try rephrasing or use a supported action.")
