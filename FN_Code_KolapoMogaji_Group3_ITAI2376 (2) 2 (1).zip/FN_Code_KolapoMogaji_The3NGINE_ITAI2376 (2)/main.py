from agent.engine import process_input

if __name__ == '__main__':
    print("Welcome to The 3NGINE - your productivity AI agent!")
    user_prompt = input("What would you like The 3NGINE to do?\n> ")
    process_input(user_prompt)
