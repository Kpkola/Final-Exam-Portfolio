# The 3NGINE - Capstone AI Agent System

Automates productivity tasks using AI and Google Calendar integration.